import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../supabase/client';
import toast from 'react-hot-toast';
import { Calendar, Clock, FileText, CheckCircle, AlertCircle } from 'lucide-react';

export function AppointmentBookingPage() {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);

    const [formData, setFormData] = useState({
        tipo: 'Primera Vez',
        fecha: '',
        hora: '',
        motivo: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!formData.fecha || !formData.hora || !formData.motivo) {
            toast.error('Por favor completa todos los campos requeridos');
            return;
        }

        setLoading(true);

        try {
            const { error } = await supabase
                .from('citas')
                .insert([
                    {
                        id_paciente: user.id,
                        fecha: formData.fecha,
                        hora: formData.hora,
                        tipo: formData.tipo,
                        motivo: formData.motivo,
                        estado: 'Pendiente' // Asumiendo que existe un estado por defecto o columna
                    }
                ]);

            if (error) throw error;

            toast.success('¡Cita agendada con éxito!');
            navigate('/dashboard');
        } catch (error) {
            console.error('Error al agendar cita:', error);
            toast.error('Error al agendar la cita. Inténtalo de nuevo.');
        } finally {
            setLoading(false);
        }
    };


    // Obtener fecha mínima (hoy)
    const today = new Date().toISOString().split('T')[0];

    // Estado para el consentimiento
    const [consentAccepted, setConsentAccepted] = useState(false);
    const [showConsentModal, setShowConsentModal] = useState(false);

    const handleConsentSubmit = async (e) => {
        e.preventDefault();

        if (!formData.fecha || !formData.hora || !formData.motivo) {
            toast.error('Por favor completa todos los campos requeridos');
            return;
        }

        if (!consentAccepted) {
            toast.error('Debes aceptar el Consentimiento Informado para continuar');
            return;
        }

        setLoading(true);

        try {
            const { error } = await supabase
                .from('citas')
                .insert([
                    {
                        id_paciente: user.id,
                        fecha: formData.fecha,
                        hora: formData.hora,
                        tipo: formData.tipo,
                        motivo: formData.motivo,
                        estado: 'Pendiente'
                    }
                ]);

            if (error) throw error;

            toast.success('¡Cita agendada con éxito!');
            navigate('/dashboard');
        } catch (error) {
            console.error('Error al agendar cita:', error);
            toast.error('Error al agendar la cita. Inténtalo de nuevo.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="max-w-2xl mx-auto py-8 px-4">
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100">

                {/* Header */}
                <div className="bg-teal-600 p-6 text-white">
                    <h1 className="text-2xl font-bold flex items-center gap-2">
                        <Calendar className="w-6 h-6" />
                        Agendar Nueva Cita
                    </h1>
                    <p className="text-teal-100 mt-2">
                        Completa el formulario para solicitar tu atención con nuestros especialistas.
                    </p>
                </div>

                {/* Formulario */}
                <form onSubmit={handleConsentSubmit} className="p-8 space-y-6">

                    {/* Tipo de Cita */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            Tipo de Cita
                        </label>
                        <div className="relative">
                            <select
                                name="tipo"
                                value={formData.tipo}
                                onChange={handleChange}
                                className="w-full pl-4 pr-10 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none appearance-none bg-gray-50 transition-all"
                            >
                                <option value="Primera Vez">Primera Vez</option>
                                <option value="Subsecuente">Subsecuente</option>
                                <option value="Tamiz">Tamiz</option>
                                <option value="Revision">Revisión</option>
                            </select>
                            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Fecha */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Fecha
                            </label>
                            <div className="relative">
                                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                                    <Calendar className="w-5 h-5" />
                                </div>
                                <input
                                    type="date"
                                    name="fecha"
                                    min={today}
                                    value={formData.fecha}
                                    onChange={handleChange}
                                    required
                                    className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none bg-gray-50 transition-all"
                                />
                            </div>
                        </div>

                        {/* Hora */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Hora Preferida
                            </label>
                            <div className="relative">
                                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                                    <Clock className="w-5 h-5" />
                                </div>
                                <input
                                    type="time"
                                    name="hora"
                                    value={formData.hora}
                                    onChange={handleChange}
                                    required
                                    className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none bg-gray-50 transition-all"
                                />
                            </div>
                        </div>
                    </div>

                    {/* Motivo */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            Motivo de Consulta
                        </label>
                        <div className="relative">
                            <div className="absolute left-3 top-4 text-gray-400">
                                <FileText className="w-5 h-5" />
                            </div>
                            <textarea
                                name="motivo"
                                value={formData.motivo}
                                onChange={handleChange}
                                required
                                rows="4"
                                placeholder="Describe brevemente tus síntomas o la razón de tu visita..."
                                className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none bg-gray-50 transition-all resize-none"
                            ></textarea>
                        </div>
                    </div>

                    {/* Consentimiento Informado */}
                    <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-xl border border-gray-200">
                        <div className="flex items-center h-5">
                            <input
                                id="consent"
                                name="consent"
                                type="checkbox"
                                checked={consentAccepted}
                                onChange={(e) => setConsentAccepted(e.target.checked)}
                                className="focus:ring-teal-500 h-5 w-5 text-teal-600 border-gray-300 rounded cursor-pointer"
                            />
                        </div>
                        <div className="text-sm">
                            <label htmlFor="consent" className="font-medium text-gray-700 cursor-pointer select-none">
                                He leído y acepto el
                            </label>
                            <button
                                type="button"
                                onClick={() => setShowConsentModal(true)}
                                className="ml-1 font-semibold text-teal-600 hover:text-teal-800 hover:underline focus:outline-none"
                            >
                                Consentimiento Informado
                            </button>
                            <span className="text-gray-700"> y los términos de servicio.</span>
                        </div>
                    </div>

                    {/* Botón Submit */}
                    <button
                        type="submit"
                        disabled={loading}
                        className={`w-full py-4 px-6 rounded-xl text-white font-semibold text-lg shadow-md transition-all flex items-center justify-center gap-2
              ${loading
                                ? 'bg-gray-400 cursor-not-allowed'
                                : 'bg-teal-600 hover:bg-teal-700 hover:shadow-lg hover:-translate-y-0.5'
                            }`}
                    >
                        {loading ? (
                            <>
                                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                Procesando...
                            </>
                        ) : (
                            <>
                                <CheckCircle className="w-5 h-5" />
                                Confirmar Cita
                            </>
                        )}
                    </button>

                </form>
            </div>

            <div className="mt-6 flex items-start gap-3 p-4 bg-blue-50 text-blue-700 rounded-xl text-sm">
                <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <p>
                    Nota: Tu cita quedará registrada como "Pendiente" hasta que sea confirmada por el especialista. Recibirás una notificación cuando esto suceda.
                </p>
            </div>

            {/* Modal de Consentimiento */}
            {showConsentModal && (
                <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
                    <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in duration-200">
                        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                            <h3 className="text-xl font-bold text-gray-800">Consentimiento Informado</h3>
                            <button
                                onClick={() => setShowConsentModal(false)}
                                className="text-gray-400 hover:text-gray-600 hover:bg-gray-200 p-1 rounded-full transition-colors"
                            >
                                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                            </button>
                        </div>
                        <div className="p-6 max-h-[60vh] overflow-y-auto text-gray-700 text-sm leading-relaxed space-y-4">
                            <p>
                                <strong>1. Objeto:</strong> Yo, como paciente, autorizo al equipo de especialistas de PROPIEL a realizar las evaluaciones, diagnósticos y tratamientos dermatológicos necesarios para mi salud.
                            </p>
                            <p>
                                <strong>2. Confidencialidad:</strong> Entiendo que toda mi información médica será tratada con estricta confidencialidad y solo será accesible por el personal autorizado.
                            </p>
                            <p>
                                <strong>3. Riesgos y Beneficios:</strong> He sido informado de que todo procedimiento médico conlleva ciertos riesgos, aunque mínimos, y acepto proceder bajo mi propia voluntad.
                            </p>
                            <p>
                                <strong>4. Compromiso:</strong> Me comprometo a proporcionar información veraz sobre mi estado de salud, antecedentes y medicamentos actuales.
                            </p>
                            <div className="bg-teal-50 p-4 rounded-lg border border-teal-100 mt-4">
                                <p className="font-medium text-teal-800">
                                    Al marcar la casilla de aceptación, confirmo que he leído, entendido y acepto los términos descritos anteriormente.
                                </p>
                            </div>
                        </div>
                        <div className="px-6 py-4 border-t border-gray-100 bg-gray-50 flex justify-end">
                            <button
                                onClick={() => {
                                    setConsentAccepted(true);
                                    setShowConsentModal(false);
                                }}
                                className="bg-teal-600 hover:bg-teal-700 text-white px-5 py-2 rounded-lg font-medium transition-colors"
                            >
                                Aceptar y Cerrar
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
